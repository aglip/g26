type Props = {
  incident: any;
  onSelect: () => void;
};

export default function IncidentCard({
  incident,
  onSelect,
}: Props) {
  return (
    <div
      onClick={onSelect}
      className="bg-slate-800 p-4 rounded-xl cursor-pointer hover:bg-slate-700 transition"
    >
      <div className="flex justify-between">
        <h2 className="font-bold text-xl">
          #{incident.id}
        </h2>

        <span className="text-red-400">
          {incident.severity}
        </span>
      </div>

      <p className="mt-2 text-lg">
        {incident.title}
      </p>
    </div>
  );
}
