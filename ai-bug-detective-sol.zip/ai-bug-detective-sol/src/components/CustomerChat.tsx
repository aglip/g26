import { useState, useRef, useEffect } from "react";
import type { Incident } from "../data/incidents";

type Message = {
  from: "customer" | "agent";
  text: string;
};

type Props = {
  incident: Incident;
};

// ---------------------------------------------------------------------------
// Mock response engine
// ---------------------------------------------------------------------------

type Intent = "symptoms" | "impact" | "when" | "experience" | "default";

function detectIntent(text: string): Intent {
  const t = text.toLowerCase();
  if (/when|start|begin|how long|since|ago|time/.test(t)) return "when";
  if (/impact|affect|cost|business|lose|loss|money|revenue|customer/.test(t)) return "impact";
  if (/see|saw|screen|page|browser|user|show|display|experience/.test(t)) return "experience";
  if (/symptom|happening|wrong|problem|issue|broken|error|fail|what/.test(t)) return "symptoms";
  return "default";
}

const OPENERS = [
  "Oh finally, a real human!",
  "FINALLY someone picks up!",
  "Do you have any idea what I'm going through right now?!",
  "I've been waiting forever for this chat to connect,",
];

const TEMPLATES: Record<Intent, ((i: Incident, variant: number) => string)[]> = {
  symptoms: [
    (i) => `Everything related to ${i.title} is completely broken in ${i.region}. My users keep hitting errors and are absolutely furious with me, as if I wrote the code myself.`,
    (i) => `${i.title} — it's just… not working. Users in ${i.region} are screaming. I don't know the technical stuff but I know things are very, very bad.`,
    (i) => `The whole ${i.title} situation is a nightmare. Something is clearly failing in ${i.region} and nobody can do what they're supposed to do.`,
  ],
  impact: [
    (i) => `We're hemorrhaging customers in ${i.region} because of this ${i.severity.toLowerCase()}-severity mess. My boss is calling me every five minutes. Please fix it.`,
    (i) => `Business is basically on pause in ${i.region}. This ${i.title} thing is costing us real money and I'm running out of excuses for my manager.`,
    (i) => `Every minute this ${i.title} is down costs us. The ${i.region} team is revolting. I may not survive this week.`,
  ],
  when: [
    (i) => `It started a couple of hours ago, out of nowhere! Status went to "${i.status}" and everything just fell apart. Nobody warned me, nobody told me anything.`,
    (i) => `Honestly? I first noticed when my inbox exploded with complaints about ${i.title}. The system went "${i.status}" and things just spiralled from there.`,
    (i) => `A few hours back. One minute everything was fine, the next — "${i.status}". ${i.region} users started flooding support almost immediately.`,
  ],
  experience: [
    (i) => `Users in ${i.region} just see errors — no helpful message, nothing. They have no idea what to do and they're coming straight to me like I'm the one who broke it.`,
    (i) => `From the user side it's basically a blank wall of failure. They try, it fails, they get angry, they email me. Rinse and repeat for the last few hours.`,
    (i) => `My users in ${i.region} can't complete their normal tasks at all. It just fails silently or throws some cryptic message. Totally unusable.`,
  ],
  default: [
    (i) => `Look, I don't know the tech details, but ${i.title} in ${i.region} is ruined right now. Can you please just fix it? My stress levels are not okay.`,
    (i) => `All I know is everything is ${i.status.toLowerCase()} and nothing works. You're the expert — you figure it out! I'm just the one suffering here.`,
    (i) => `I'm not sure how to answer that, but I can confirm ${i.title} is a disaster. Status: ${i.status}. Region: ${i.region}. My sanity: gone.`,
  ],
};

function getMockResponse(incident: Incident, userText: string): string {
  const intent = detectIntent(userText);
  const templates = TEMPLATES[intent];
  const variant = incident.id % templates.length;
  return templates[variant](incident);
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export default function CustomerChat({ incident }: Props) {
  const opener = OPENERS[incident.id % OPENERS.length];
  const [messages, setMessages] = useState<Message[]>([
    {
      from: "customer",
      text: `${opener} I need help with incident #${incident.id}: ${incident.title}. This is a ${incident.severity} severity issue in ${incident.region}!`,
    },
  ]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  function handleSend() {
    const text = input.trim();
    if (!text) return;

    const agentMsg: Message = { from: "agent", text };
    setMessages((prev) => [...prev, agentMsg]);
    setInput("");
    setTyping(true);

    setTimeout(() => {
      const reply = getMockResponse(incident, text);
      setMessages((prev) => [...prev, { from: "customer", text: reply }]);
      setTyping(false);
    }, 900 + Math.random() * 600);
  }

  function handleKey(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  return (
    <div className="bg-slate-800 rounded-xl mt-4 flex flex-col" style={{ height: "340px" }}>
      <div className="px-4 py-3 border-b border-slate-700 flex items-center gap-2">
        <span className="text-lg">😤</span>
        <span className="font-bold text-white">Customer Chat</span>
        <span className="ml-auto text-xs text-slate-400">Incident #{incident.id}</span>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex gap-2 ${msg.from === "agent" ? "flex-row-reverse" : ""}`}
          >
            <span className="text-xl flex-shrink-0 mt-0.5">
              {msg.from === "customer" ? "😤" : "🕵️"}
            </span>
            <div
              className={`max-w-xs rounded-2xl px-3 py-2 text-sm leading-relaxed ${
                msg.from === "customer"
                  ? "bg-slate-700 text-slate-100 rounded-tl-sm"
                  : "bg-blue-700 text-white rounded-tr-sm"
              }`}
            >
              {msg.text}
            </div>
          </div>
        ))}

        {typing && (
          <div className="flex gap-2">
            <span className="text-xl">😤</span>
            <div className="bg-slate-700 rounded-2xl rounded-tl-sm px-4 py-2 text-slate-400 text-sm">
              typing…
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      <div className="px-4 py-3 border-t border-slate-700 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKey}
          placeholder="Ask about symptoms, impact, timing…"
          className="flex-1 bg-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-400 outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          onClick={handleSend}
          disabled={!input.trim() || typing}
          className="bg-blue-600 hover:bg-blue-500 disabled:opacity-40 disabled:cursor-not-allowed px-4 py-2 rounded-lg text-sm font-semibold transition"
        >
          Send
        </button>
      </div>
    </div>
  );
}
