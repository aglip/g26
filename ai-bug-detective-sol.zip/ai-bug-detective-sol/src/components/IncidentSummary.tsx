import { useState } from "react";
import type { Incident } from "../data/incidents";

type Props = {
  incident: Incident;
};

// ---------------------------------------------------------------------------
// Mock summary builder — uses only safe fields (no answers / explanation)
// ---------------------------------------------------------------------------

function buildSummary(incident: Incident): string[] {
  const { title, severity, region, status, logs } = incident;

  // Derive a short service name from the incident title
  const service = title;

  // Business impact phrasing varies by severity
  const impactMap: Record<string, string> = {
    HIGH: "Significant customer-facing disruption; immediate revenue or trust impact likely.",
    MEDIUM: "Degraded experience for a subset of users; escalation risk if unresolved.",
    LOW: "Minor inconvenience; limited blast radius but worth resolving to prevent spread.",
  };
  const impact = impactMap[severity] ?? "Impact scope under assessment.";

  // Next-step recommendation varies by status
  const nextStepMap: Record<string, string> = {
    ACTIVE: "Escalate immediately — assign an on-call engineer and open a war-room channel.",
    INVESTIGATING: "Correlate recent deployments and config changes with the onset time.",
    MONITORING: "Confirm metric recovery; set an auto-resolve threshold before closing the ticket.",
  };
  const nextStep = nextStepMap[status] ?? "Review recent changes and verify system metrics.";

  // Pick the most informative-looking log line (last non-empty line)
  const symptomLog = [...logs].reverse().find((l) => l.trim()) ?? logs[0];

  return [
    `🛠 **Affected service:** ${service} (${region})`,
    `🚨 **Severity / Status:** ${severity} — ${status}`,
    `📋 **Visible symptoms:** ${symptomLog}`,
    `💸 **Likely business impact:** ${impact}`,
    `🔍 **Recommended next step:** ${nextStep}`,
  ];
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export default function IncidentSummary({ incident }: Props) {
  const [state, setState] = useState<"idle" | "generating" | "done">("idle");
  const [bullets, setBullets] = useState<string[]>([]);

  function handleGenerate() {
    setState("generating");
    setTimeout(() => {
      setBullets(buildSummary(incident));
      setState("done");
    }, 900);
  }

  // Bold text helper: renders **text** as <strong>
  function renderBullet(line: string, i: number) {
    const parts = line.split(/\*\*(.*?)\*\*/g);
    return (
      <li key={i} className="text-sm text-slate-200 leading-relaxed">
        {parts.map((part, j) =>
          j % 2 === 1 ? <strong key={j} className="text-white">{part}</strong> : part
        )}
      </li>
    );
  }

  return (
    <div className="bg-slate-800 rounded-xl mt-4 p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-bold text-lg text-white">Incident Summary</h3>
        <button
          onClick={handleGenerate}
          disabled={state === "generating"}
          className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed px-4 py-1.5 rounded-lg text-sm font-semibold transition"
        >
          {state === "generating" ? "Generating…" : "Generate Summary"}
        </button>
      </div>

      {state === "idle" && (
        <p className="text-slate-500 text-sm">
          Click "Generate Summary" to produce a structured overview of this incident.
        </p>
      )}

      {state === "generating" && (
        <div className="flex items-center gap-2 text-slate-400 text-sm">
          <span className="animate-spin">⚙️</span>
          <span>Analysing incident data…</span>
        </div>
      )}

      {state === "done" && (
        <ul className="space-y-2 list-none">
          {bullets.map((b, i) => renderBullet(b, i))}
        </ul>
      )}
    </div>
  );
}
