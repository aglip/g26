type Props = {
  score: number;
};

export default function Header({ score }: Props) {
  return (
    <div className="p-4 border-b border-slate-700 mb-6 flex items-center justify-between">
      <div>
        <h1 className="text-3xl font-bold">
          AI Bug Detective
        </h1>
        <p className="text-slate-400 mt-2">
          Investigate production incidents.
        </p>
      </div>
      <div className="text-right">
        <p className="text-slate-400 text-xs uppercase tracking-widest mb-1">Score</p>
        <p className="text-3xl font-bold text-yellow-400">{score}</p>
      </div>
    </div>
  );
}
