type Props = {
  logs: string[];
};

export default function LogViewer({ logs }: Props) {
  return (
    <div className="bg-black rounded-xl p-4 mt-6">
      <h3 className="mb-4 font-bold text-green-400">
        Logs
      </h3>

      <div className="space-y-2 text-sm font-mono">
        {logs.map((log, index) => (
          <div key={index}>
            {log}
          </div>
        ))}
      </div>
    </div>
  );
}
