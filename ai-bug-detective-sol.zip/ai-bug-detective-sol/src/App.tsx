import { useState, useEffect } from "react";
import Header from "./components/Header";
import IncidentCard from "./components/IncidentCard";
import LogViewer from "./components/LogViewer";
import RootCauseQuiz from "./components/RootCauseQuiz";
import CustomerChat from "./components/CustomerChat";
import IncidentSummary from "./components/IncidentSummary";
import { incidents } from "./data/incidents";

const SEVERITY_FILTERS = ["All", "HIGH", "MEDIUM", "LOW"] as const;
type SeverityFilter = (typeof SEVERITY_FILTERS)[number];

const severityButtonClass: Record<SeverityFilter, string> = {
  All: "bg-slate-600 hover:bg-slate-500",
  HIGH: "bg-red-700 hover:bg-red-600",
  MEDIUM: "bg-yellow-600 hover:bg-yellow-500",
  LOW: "bg-green-700 hover:bg-green-600",
};

function formatElapsed(seconds: number): string {
  const h = Math.floor(seconds / 3600).toString().padStart(2, "0");
  const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, "0");
  const s = (seconds % 60).toString().padStart(2, "0");
  return `${h}:${m}:${s}`;
}

export default function App() {
  const [selected, setSelected] = useState(incidents[0]);
  const [severityFilter, setSeverityFilter] = useState<SeverityFilter>("All");
  const [elapsed, setElapsed] = useState(0);
  const [score, setScore] = useState(0);
  const [scoredIds, setScoredIds] = useState<Set<number>>(new Set());

  useEffect(() => {
    setElapsed(0);
    const id = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => clearInterval(id);
  }, [selected.id]);

  const filtered =
    severityFilter === "All"
      ? incidents
      : incidents.filter((i) => i.severity === severityFilter);

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <Header score={score} />

      <div className="flex gap-2 px-4 pt-4">
        {SEVERITY_FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setSeverityFilter(f)}
            className={`px-4 py-1.5 rounded-full text-sm font-semibold transition ${severityButtonClass[f]} ${
              severityFilter === f
                ? "ring-2 ring-white ring-offset-1 ring-offset-slate-900"
                : "opacity-70"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-4 p-4">
        {filtered.length === 0 ? (
          <p className="col-span-2 text-center text-slate-400 py-12 text-lg">
            No incidents match the <span className="font-bold text-white">{severityFilter}</span> severity filter.
          </p>
        ) : (
          filtered.map((incident) => (
            <IncidentCard
              key={incident.id}
              incident={incident}
              onSelect={() => setSelected(incident)}
            />
          ))
        )}
      </div>

      <div className="p-4">
        <div className="flex items-center gap-3 mb-3">
          <span className="text-slate-400 text-sm">Investigating #{selected.id} — {selected.title}</span>
          <span className="font-mono text-lg font-bold tracking-widest text-yellow-400">
            {formatElapsed(elapsed)}
          </span>
        </div>
        <LogViewer logs={selected.logs} />
        <RootCauseQuiz
          key={selected.id}
          answers={selected.answers}
          explanation={selected.explanation}
          onCorrect={() => {
            if (!scoredIds.has(selected.id)) {
              setScore((s) => s + 10);
              setScoredIds((prev) => new Set(prev).add(selected.id));
            }
          }}
        />
        <IncidentSummary key={`summary-${selected.id}`} incident={selected} />
        <CustomerChat key={`chat-${selected.id}`} incident={selected} />
      </div>
    </div>
  );
}
