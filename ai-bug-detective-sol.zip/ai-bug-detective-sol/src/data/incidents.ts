export type Answer = {
  text: string;
  correct: boolean;
};

export type Incident = {
  id: number;
  title: string;
  severity: string;
  region: string;
  status: string;
  logs: string[];
  answers: Answer[];
  explanation: string;
};

export const incidents: Incident[] = [
  {
    id: 1042,
    title: "Payment API Failure",
    severity: "HIGH",
    region: "Germany",
    status: "ACTIVE",
    logs: [
      "[ERROR] CurrencyFormatter.cs:84",
      "NullReferenceException",
      "EUR payments failing",
    ],
    answers: [
      {
        text: "CurrencyFormatter received a null locale config for EUR",
        correct: true,
      },
      {
        text: "The payment gateway SSL certificate expired",
        correct: false,
      },
      {
        text: "Database connection pool was exhausted",
        correct: false,
      },
    ],
    explanation:
      "The stack trace points to CurrencyFormatter.cs line 84, which throws a NullReferenceException when the EUR locale config is missing. This caused all EUR payment attempts to fail.",
  },
  {
    id: 1043,
    title: "Slow Checkout Response",
    severity: "MEDIUM",
    region: "US-East",
    status: "INVESTIGATING",
    logs: [
      "[WARN] CheckoutService.java:210",
      "Response time exceeded 3000ms",
      "Affected 12% of checkout requests",
    ],
    answers: [
      {
        text: "A missing database index caused a full table scan on order lookup",
        correct: true,
      },
      {
        text: "The CDN cache was purged accidentally",
        correct: false,
      },
      {
        text: "A new deployment rolled back automatically",
        correct: false,
      },
    ],
    explanation:
      "CheckoutService.java line 210 performs an order lookup that began doing a full table scan after a recent migration dropped the composite index on order_id + user_id.",
  },
  {
    id: 1044,
    title: "Email Notification Delay",
    severity: "LOW",
    region: "Global",
    status: "MONITORING",
    logs: [
      "[INFO] MailWorker.py:55",
      "Queue depth: 4200 messages",
      "Average delay: 8 minutes",
    ],
    answers: [
      {
        text: "The mail worker concurrency limit was set too low after a config change",
        correct: true,
      },
      {
        text: "The SMTP server's TLS certificate expired",
        correct: false,
      },
      {
        text: "Email templates were missing required fields",
        correct: false,
      },
    ],
    explanation:
      "MailWorker.py line 55 shows the queue depth growing. A recent config change reduced worker concurrency from 20 to 2, causing messages to pile up and delays to spike.",
  },
  {
    id: 1045,
    title: "Database Connection Pool Exhausted",
    severity: "HIGH",
    region: "US-West",
    status: "ACTIVE",
    logs: [
      "[ERROR] ConnectionPool.java:302",
      "Timeout acquiring connection after 30000ms",
      "Active connections: 100/100 — pool exhausted",
    ],
    answers: [
      {
        text: "A missing await in a loop caused connections to be acquired but never released",
        correct: true,
      },
      {
        text: "The database server ran out of disk space",
        correct: false,
      },
      {
        text: "A firewall rule blocked new TCP connections to port 5432",
        correct: false,
      },
    ],
    explanation:
      "ConnectionPool.java line 302 shows the pool is full. A recently merged async refactor omitted await on a query inside a loop, causing each iteration to hold a connection open indefinitely until the pool was saturated.",
  },
  {
    id: 1046,
    title: "Expired API Certificate",
    severity: "HIGH",
    region: "EU-Central",
    status: "ACTIVE",
    logs: [
      "[ERROR] HttpClient.go:88",
      "x509: certificate has expired or is not yet valid",
      "All outbound API calls to partner-api.example.com failing",
    ],
    answers: [
      {
        text: "The TLS certificate for partner-api.example.com expired and was not auto-renewed",
        correct: true,
      },
      {
        text: "The server clock drifted more than 5 minutes out of sync",
        correct: false,
      },
      {
        text: "The API key was rotated without updating the client config",
        correct: false,
      },
    ],
    explanation:
      "HttpClient.go line 88 surfaces the x509 expiry error. The Let's Encrypt auto-renewal cron job had been silently failing for 30 days due to a DNS validation misconfiguration, causing the cert to lapse.",
  },
  {
    id: 1047,
    title: "AI Classifier Random Output",
    severity: "MEDIUM",
    region: "Global",
    status: "INVESTIGATING",
    logs: [
      "[WARN] Classifier.py:145",
      "Model returned confidence < 0.10 for 78% of inputs",
      "Feature vector shape mismatch: expected (1, 512), got (1, 256)",
    ],
    answers: [
      {
        text: "A preprocessing pipeline change halved the feature vector size, breaking the deployed model",
        correct: true,
      },
      {
        text: "The GPU ran out of VRAM and fell back to random weight initialization",
        correct: false,
      },
      {
        text: "The model checkpoint file was corrupted during the last deployment",
        correct: false,
      },
    ],
    explanation:
      "Classifier.py line 145 logs the shape mismatch. A new data pipeline truncated embeddings to 256 dimensions while the production model still expected 512, causing nearly all predictions to be near-random.",
  },
  {
    id: 1048,
    title: "Frontend Login Loop",
    severity: "HIGH",
    region: "Asia-Pacific",
    status: "ACTIVE",
    logs: [
      "[ERROR] AuthMiddleware.ts:61",
      "Redirect loop detected: /login → /dashboard → /login",
      "Set-Cookie header missing Secure flag — cookie dropped by browser",
    ],
    answers: [
      {
        text: "The session cookie was missing the Secure flag, so HTTPS browsers silently dropped it, causing repeated auth failures",
        correct: true,
      },
      {
        text: "The OAuth provider revoked the application's client credentials",
        correct: false,
      },
      {
        text: "A reverse proxy was stripping the Authorization header before it reached the app",
        correct: false,
      },
    ],
    explanation:
      "AuthMiddleware.ts line 61 catches the redirect cycle. After a load balancer was upgraded to enforce HTTPS, the session cookie (set without the Secure attribute) was silently rejected by browsers, making every authenticated request appear unauthenticated.",
  },
  {
    id: 1049,
    title: "Slow Search Service",
    severity: "MEDIUM",
    region: "US-East",
    status: "MONITORING",
    logs: [
      "[WARN] SearchHandler.rb:77",
      "Elasticsearch query latency p99: 12400ms (SLA: 500ms)",
      "Shard count for index 'products': 1 (expected 8)",
    ],
    answers: [
      {
        text: "The products index was recreated with only 1 shard after a reindex, removing parallelism",
        correct: true,
      },
      {
        text: "Elasticsearch JVM heap was undersized causing frequent garbage collection pauses",
        correct: false,
      },
      {
        text: "A wildcard query was missing an index alias and falling back to a full cluster scan",
        correct: false,
      },
    ],
    explanation:
      "SearchHandler.rb line 77 reveals the shard count dropped from 8 to 1. During a late-night reindex to add a new field, the index template was not applied, creating a single-shard index that serialised all queries and blew past the 500ms SLA.",
  },
  {
    id: 1050,
    title: "Memory Leak in Node.js Service",
    severity: "HIGH",
    region: "US-East",
    status: "ACTIVE",
    logs: [
      "[ERROR] ProcessMonitor:22",
      "RSS memory: 4.1 GB — OOM kill imminent",
      "EventEmitter 'data' listener count: 14802 (threshold: 10)",
    ],
    answers: [
      {
        text: "Event listeners were added inside a request handler but never removed, accumulating on every request",
        correct: true,
      },
      {
        text: "A third-party NPM package pinned to an outdated version had a known memory leak",
        correct: false,
      },
      {
        text: "The Node.js garbage collector was disabled via --expose-gc flag",
        correct: false,
      },
    ],
    explanation:
      "ProcessMonitor shows the EventEmitter listener count climbing with each request. A streaming response handler registered a 'data' listener per request but called removeListener only on clean closes — unhandled aborts left listeners permanently attached, growing RSS until OOM.",
  },
  {
    id: 1051,
    title: "Redis Cache Stampede",
    severity: "MEDIUM",
    region: "EU-West",
    status: "INVESTIGATING",
    logs: [
      "[WARN] CacheLayer.ts:119",
      "Cache miss rate spiked to 98% at 09:00 UTC",
      "DB query rate: 42,000 req/s (normal: 800 req/s)",
    ],
    answers: [
      {
        text: "All cache keys expired simultaneously because they were set with the same fixed TTL during a bulk load",
        correct: true,
      },
      {
        text: "Redis ran out of memory and evicted all keys using the allkeys-lru policy",
        correct: false,
      },
      {
        text: "A misconfigured health check flushed the Redis keyspace every 60 seconds",
        correct: false,
      },
    ],
    explanation:
      "CacheLayer.ts line 119 shows the cache miss rate. During the previous night's bulk data import, every cache entry was written with an identical TTL of 8 hours, causing all keys to expire at exactly 09:00 UTC — triggering a thundering-herd stampede directly to the database.",
  },
  {
    id: 1052,
    title: "Misconfigured CORS Policy",
    severity: "LOW",
    region: "Global",
    status: "MONITORING",
    logs: [
      "[WARN] ApiGateway.js:44",
      "CORS preflight rejected: Origin 'https://app.example.com' not in allowlist",
      "Affected endpoints: /api/v2/profile, /api/v2/settings",
    ],
    answers: [
      {
        text: "The v2 API routes were added without updating the CORS allowlist to include the production origin",
        correct: true,
      },
      {
        text: "The browser blocked requests because the API response lacked a Content-Security-Policy header",
        correct: false,
      },
      {
        text: "An nginx upgrade reset the Access-Control-Allow-Origin header to its default empty value",
        correct: false,
      },
    ],
    explanation:
      "ApiGateway.js line 44 logs the rejected origin. When /api/v2 routes were introduced, the CORS middleware config was copied from v1 but the production frontend origin was accidentally omitted from the allowlist, blocking all cross-origin preflight requests to the new endpoints.",
  },
];
