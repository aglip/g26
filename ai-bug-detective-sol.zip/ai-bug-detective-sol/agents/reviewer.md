Review implementation for:
- unnecessary complexity
- missing validation
- duplicated logic
