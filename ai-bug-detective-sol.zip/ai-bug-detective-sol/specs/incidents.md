# Incident 1

Payment API Failure

Symptoms:
- EUR payments failing
- Germany only
