# Extension Tasks

## Easy
Add severity filtering.

## Medium
Add root-cause quiz.

## Advanced
Add AI customer chat.
