# Product Vision

AI Bug Detective is an interactive incident-response simulator.

Players investigate realistic software failures.
