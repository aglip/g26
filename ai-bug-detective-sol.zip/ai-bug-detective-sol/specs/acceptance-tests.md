# Acceptance Tests

- Incident cards visible
- Log viewer updates
- Responsive layout works
