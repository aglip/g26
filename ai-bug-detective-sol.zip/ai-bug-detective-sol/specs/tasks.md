# Tasks

## Task 1
Create incident dashboard UI.

## Task 2
Add log viewer.

## Task 3
Add AI customer chat.
