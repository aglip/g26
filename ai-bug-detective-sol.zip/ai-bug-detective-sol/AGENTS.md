# AI Bug Detective Agent Rules

Always read /specs first.

Workflow:
1. Analyze specs
2. Implement ONE task only
3. Verify functionality
4. Explain testing steps

Rules:
- Never fake logs
- Keep components modular
- Do not rewrite unrelated files
- Add validation where needed
- Prefer simple solutions
