export type Answer = {
  text: string;
  correct: boolean;
};

export type Incident = {
  id: number;
  title: string;
  severity: string;
  region: string;
  status: string;
  logs: string[];
  answers: Answer[];
  explanation: string;
};

export const incidents: Incident[] = [
  {
    id: 1042,
    title: "Payment API Failure",
    severity: "HIGH",
    region: "Germany",
    status: "ACTIVE",
    logs: [
      "[ERROR] CurrencyFormatter.cs:84",
      "NullReferenceException",
      "EUR payments failing",
    ],
    answers: [
      {
        text: "CurrencyFormatter received a null locale config for EUR",
        correct: true,
      },
      {
        text: "The payment gateway SSL certificate expired",
        correct: false,
      },
      {
        text: "Database connection pool was exhausted",
        correct: false,
      },
    ],
    explanation:
      "The stack trace points to CurrencyFormatter.cs line 84, which throws a NullReferenceException when the EUR locale config is missing. This caused all EUR payment attempts to fail.",
  },
];
