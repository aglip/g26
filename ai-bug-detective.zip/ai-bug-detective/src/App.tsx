import { useState } from "react";
import Header from "./components/Header";
import IncidentCard from "./components/IncidentCard";
import LogViewer from "./components/LogViewer";
import RootCauseQuiz from "./components/RootCauseQuiz";
import { incidents } from "./data/incidents";

export default function App() {
  const [selected, setSelected] = useState(incidents[0]);

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <Header />

      <div className="grid md:grid-cols-2 gap-4 p-4">
        {incidents.map((incident) => (
          <IncidentCard
            key={incident.id}
            incident={incident}
            onSelect={() => setSelected(incident)}
          />
        ))}
      </div>

      <div className="p-4">
        <LogViewer logs={selected.logs} />
        <RootCauseQuiz
          key={selected.id}
          answers={selected.answers}
          explanation={selected.explanation}
        />
      </div>
    </div>
  );
}
