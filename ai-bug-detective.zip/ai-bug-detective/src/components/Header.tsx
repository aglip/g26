export default function Header() {
  return (
    <div className="p-4 border-b border-slate-700 mb-6">
      <h1 className="text-3xl font-bold">
        AI Bug Detective
      </h1>

      <p className="text-slate-400 mt-2">
        Investigate production incidents.
      </p>
    </div>
  );
}
