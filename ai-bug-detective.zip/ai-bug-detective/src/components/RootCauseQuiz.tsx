import { useState } from "react";
import type { Answer } from "../data/incidents";

type Props = {
  answers: Answer[];
  explanation: string;
};

export default function RootCauseQuiz({ answers, explanation }: Props) {
  const [selected, setSelected] = useState<number | null>(null);

  const handleSelect = (index: number) => {
    if (selected !== null) return;
    setSelected(index);
  };

  const isCorrect = selected !== null && answers[selected].correct;

  return (
    <div className="bg-slate-800 rounded-xl p-4 mt-4">
      <h3 className="font-bold text-lg mb-3 text-white">
        What is the root cause?
      </h3>

      <div className="space-y-2">
        {answers.map((answer, index) => {
          let buttonStyle =
            "w-full text-left px-4 py-3 rounded-lg border transition text-sm ";

          if (selected === null) {
            buttonStyle +=
              "border-slate-600 bg-slate-700 hover:bg-slate-600 text-white cursor-pointer";
          } else if (index === selected) {
            buttonStyle += answer.correct
              ? "border-green-500 bg-green-900/40 text-green-300 cursor-default"
              : "border-red-500 bg-red-900/40 text-red-300 cursor-default";
          } else if (answer.correct) {
            buttonStyle +=
              "border-green-500 bg-green-900/20 text-green-400 cursor-default";
          } else {
            buttonStyle +=
              "border-slate-600 bg-slate-700 text-slate-400 cursor-default";
          }

          return (
            <button
              key={index}
              className={buttonStyle}
              onClick={() => handleSelect(index)}
              disabled={selected !== null}
            >
              {answer.text}
            </button>
          );
        })}
      </div>

      {selected !== null && (
        <div
          className={`mt-4 p-3 rounded-lg text-sm ${
            isCorrect
              ? "bg-green-900/30 border border-green-600 text-green-300"
              : "bg-red-900/30 border border-red-600 text-red-300"
          }`}
        >
          <p className="font-bold mb-1">{isCorrect ? "Correct!" : "Wrong!"}</p>
          <p className="text-slate-300">{explanation}</p>
        </div>
      )}
    </div>
  );
}
